// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.1 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xeuchw.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XEuchw_CfgInitialize(XEuchw *InstancePtr, XEuchw_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XEuchw_Start(XEuchw *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEuchw_ReadReg(InstancePtr->Control_BaseAddress, XEUCHW_CONTROL_ADDR_AP_CTRL) & 0x80;
    XEuchw_WriteReg(InstancePtr->Control_BaseAddress, XEUCHW_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XEuchw_IsDone(XEuchw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEuchw_ReadReg(InstancePtr->Control_BaseAddress, XEUCHW_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XEuchw_IsIdle(XEuchw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEuchw_ReadReg(InstancePtr->Control_BaseAddress, XEUCHW_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XEuchw_IsReady(XEuchw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEuchw_ReadReg(InstancePtr->Control_BaseAddress, XEUCHW_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XEuchw_EnableAutoRestart(XEuchw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEuchw_WriteReg(InstancePtr->Control_BaseAddress, XEUCHW_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XEuchw_DisableAutoRestart(XEuchw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEuchw_WriteReg(InstancePtr->Control_BaseAddress, XEUCHW_CONTROL_ADDR_AP_CTRL, 0);
}

u32 XEuchw_Get_C(XEuchw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEuchw_ReadReg(InstancePtr->Control_BaseAddress, XEUCHW_CONTROL_ADDR_C_DATA);
    return Data;
}

u32 XEuchw_Get_C_vld(XEuchw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEuchw_ReadReg(InstancePtr->Control_BaseAddress, XEUCHW_CONTROL_ADDR_C_CTRL);
    return Data & 0x1;
}

u32 XEuchw_Get_AB_0_BaseAddress(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_0_BASE);
}

u32 XEuchw_Get_AB_0_HighAddress(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_0_HIGH);
}

u32 XEuchw_Get_AB_0_TotalBytes(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XEUCHW_CONTROL_ADDR_AB_0_HIGH - XEUCHW_CONTROL_ADDR_AB_0_BASE + 1);
}

u32 XEuchw_Get_AB_0_BitWidth(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XEUCHW_CONTROL_WIDTH_AB_0;
}

u32 XEuchw_Get_AB_0_Depth(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XEUCHW_CONTROL_DEPTH_AB_0;
}

u32 XEuchw_Write_AB_0_Words(XEuchw *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XEUCHW_CONTROL_ADDR_AB_0_HIGH - XEUCHW_CONTROL_ADDR_AB_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_0_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XEuchw_Read_AB_0_Words(XEuchw *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XEUCHW_CONTROL_ADDR_AB_0_HIGH - XEUCHW_CONTROL_ADDR_AB_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_0_BASE + (offset + i)*4);
    }
    return length;
}

u32 XEuchw_Write_AB_0_Bytes(XEuchw *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XEUCHW_CONTROL_ADDR_AB_0_HIGH - XEUCHW_CONTROL_ADDR_AB_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_0_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XEuchw_Read_AB_0_Bytes(XEuchw *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XEUCHW_CONTROL_ADDR_AB_0_HIGH - XEUCHW_CONTROL_ADDR_AB_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_0_BASE + offset + i);
    }
    return length;
}

u32 XEuchw_Get_AB_1_BaseAddress(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_1_BASE);
}

u32 XEuchw_Get_AB_1_HighAddress(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_1_HIGH);
}

u32 XEuchw_Get_AB_1_TotalBytes(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XEUCHW_CONTROL_ADDR_AB_1_HIGH - XEUCHW_CONTROL_ADDR_AB_1_BASE + 1);
}

u32 XEuchw_Get_AB_1_BitWidth(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XEUCHW_CONTROL_WIDTH_AB_1;
}

u32 XEuchw_Get_AB_1_Depth(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XEUCHW_CONTROL_DEPTH_AB_1;
}

u32 XEuchw_Write_AB_1_Words(XEuchw *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XEUCHW_CONTROL_ADDR_AB_1_HIGH - XEUCHW_CONTROL_ADDR_AB_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_1_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XEuchw_Read_AB_1_Words(XEuchw *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XEUCHW_CONTROL_ADDR_AB_1_HIGH - XEUCHW_CONTROL_ADDR_AB_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_1_BASE + (offset + i)*4);
    }
    return length;
}

u32 XEuchw_Write_AB_1_Bytes(XEuchw *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XEUCHW_CONTROL_ADDR_AB_1_HIGH - XEUCHW_CONTROL_ADDR_AB_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_1_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XEuchw_Read_AB_1_Bytes(XEuchw *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XEUCHW_CONTROL_ADDR_AB_1_HIGH - XEUCHW_CONTROL_ADDR_AB_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_1_BASE + offset + i);
    }
    return length;
}

u32 XEuchw_Get_AB_2_BaseAddress(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_2_BASE);
}

u32 XEuchw_Get_AB_2_HighAddress(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_2_HIGH);
}

u32 XEuchw_Get_AB_2_TotalBytes(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XEUCHW_CONTROL_ADDR_AB_2_HIGH - XEUCHW_CONTROL_ADDR_AB_2_BASE + 1);
}

u32 XEuchw_Get_AB_2_BitWidth(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XEUCHW_CONTROL_WIDTH_AB_2;
}

u32 XEuchw_Get_AB_2_Depth(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XEUCHW_CONTROL_DEPTH_AB_2;
}

u32 XEuchw_Write_AB_2_Words(XEuchw *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XEUCHW_CONTROL_ADDR_AB_2_HIGH - XEUCHW_CONTROL_ADDR_AB_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_2_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XEuchw_Read_AB_2_Words(XEuchw *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XEUCHW_CONTROL_ADDR_AB_2_HIGH - XEUCHW_CONTROL_ADDR_AB_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_2_BASE + (offset + i)*4);
    }
    return length;
}

u32 XEuchw_Write_AB_2_Bytes(XEuchw *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XEUCHW_CONTROL_ADDR_AB_2_HIGH - XEUCHW_CONTROL_ADDR_AB_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_2_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XEuchw_Read_AB_2_Bytes(XEuchw *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XEUCHW_CONTROL_ADDR_AB_2_HIGH - XEUCHW_CONTROL_ADDR_AB_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_2_BASE + offset + i);
    }
    return length;
}

u32 XEuchw_Get_AB_3_BaseAddress(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_3_BASE);
}

u32 XEuchw_Get_AB_3_HighAddress(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_3_HIGH);
}

u32 XEuchw_Get_AB_3_TotalBytes(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XEUCHW_CONTROL_ADDR_AB_3_HIGH - XEUCHW_CONTROL_ADDR_AB_3_BASE + 1);
}

u32 XEuchw_Get_AB_3_BitWidth(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XEUCHW_CONTROL_WIDTH_AB_3;
}

u32 XEuchw_Get_AB_3_Depth(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XEUCHW_CONTROL_DEPTH_AB_3;
}

u32 XEuchw_Write_AB_3_Words(XEuchw *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XEUCHW_CONTROL_ADDR_AB_3_HIGH - XEUCHW_CONTROL_ADDR_AB_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_3_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XEuchw_Read_AB_3_Words(XEuchw *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XEUCHW_CONTROL_ADDR_AB_3_HIGH - XEUCHW_CONTROL_ADDR_AB_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_3_BASE + (offset + i)*4);
    }
    return length;
}

u32 XEuchw_Write_AB_3_Bytes(XEuchw *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XEUCHW_CONTROL_ADDR_AB_3_HIGH - XEUCHW_CONTROL_ADDR_AB_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_3_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XEuchw_Read_AB_3_Bytes(XEuchw *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XEUCHW_CONTROL_ADDR_AB_3_HIGH - XEUCHW_CONTROL_ADDR_AB_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_3_BASE + offset + i);
    }
    return length;
}

u32 XEuchw_Get_AB_4_BaseAddress(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_4_BASE);
}

u32 XEuchw_Get_AB_4_HighAddress(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_4_HIGH);
}

u32 XEuchw_Get_AB_4_TotalBytes(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XEUCHW_CONTROL_ADDR_AB_4_HIGH - XEUCHW_CONTROL_ADDR_AB_4_BASE + 1);
}

u32 XEuchw_Get_AB_4_BitWidth(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XEUCHW_CONTROL_WIDTH_AB_4;
}

u32 XEuchw_Get_AB_4_Depth(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XEUCHW_CONTROL_DEPTH_AB_4;
}

u32 XEuchw_Write_AB_4_Words(XEuchw *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XEUCHW_CONTROL_ADDR_AB_4_HIGH - XEUCHW_CONTROL_ADDR_AB_4_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_4_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XEuchw_Read_AB_4_Words(XEuchw *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XEUCHW_CONTROL_ADDR_AB_4_HIGH - XEUCHW_CONTROL_ADDR_AB_4_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_4_BASE + (offset + i)*4);
    }
    return length;
}

u32 XEuchw_Write_AB_4_Bytes(XEuchw *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XEUCHW_CONTROL_ADDR_AB_4_HIGH - XEUCHW_CONTROL_ADDR_AB_4_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_4_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XEuchw_Read_AB_4_Bytes(XEuchw *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XEUCHW_CONTROL_ADDR_AB_4_HIGH - XEUCHW_CONTROL_ADDR_AB_4_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_4_BASE + offset + i);
    }
    return length;
}

u32 XEuchw_Get_AB_5_BaseAddress(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_5_BASE);
}

u32 XEuchw_Get_AB_5_HighAddress(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_5_HIGH);
}

u32 XEuchw_Get_AB_5_TotalBytes(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XEUCHW_CONTROL_ADDR_AB_5_HIGH - XEUCHW_CONTROL_ADDR_AB_5_BASE + 1);
}

u32 XEuchw_Get_AB_5_BitWidth(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XEUCHW_CONTROL_WIDTH_AB_5;
}

u32 XEuchw_Get_AB_5_Depth(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XEUCHW_CONTROL_DEPTH_AB_5;
}

u32 XEuchw_Write_AB_5_Words(XEuchw *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XEUCHW_CONTROL_ADDR_AB_5_HIGH - XEUCHW_CONTROL_ADDR_AB_5_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_5_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XEuchw_Read_AB_5_Words(XEuchw *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XEUCHW_CONTROL_ADDR_AB_5_HIGH - XEUCHW_CONTROL_ADDR_AB_5_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_5_BASE + (offset + i)*4);
    }
    return length;
}

u32 XEuchw_Write_AB_5_Bytes(XEuchw *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XEUCHW_CONTROL_ADDR_AB_5_HIGH - XEUCHW_CONTROL_ADDR_AB_5_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_5_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XEuchw_Read_AB_5_Bytes(XEuchw *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XEUCHW_CONTROL_ADDR_AB_5_HIGH - XEUCHW_CONTROL_ADDR_AB_5_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_5_BASE + offset + i);
    }
    return length;
}

u32 XEuchw_Get_AB_6_BaseAddress(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_6_BASE);
}

u32 XEuchw_Get_AB_6_HighAddress(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_6_HIGH);
}

u32 XEuchw_Get_AB_6_TotalBytes(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XEUCHW_CONTROL_ADDR_AB_6_HIGH - XEUCHW_CONTROL_ADDR_AB_6_BASE + 1);
}

u32 XEuchw_Get_AB_6_BitWidth(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XEUCHW_CONTROL_WIDTH_AB_6;
}

u32 XEuchw_Get_AB_6_Depth(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XEUCHW_CONTROL_DEPTH_AB_6;
}

u32 XEuchw_Write_AB_6_Words(XEuchw *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XEUCHW_CONTROL_ADDR_AB_6_HIGH - XEUCHW_CONTROL_ADDR_AB_6_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_6_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XEuchw_Read_AB_6_Words(XEuchw *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XEUCHW_CONTROL_ADDR_AB_6_HIGH - XEUCHW_CONTROL_ADDR_AB_6_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_6_BASE + (offset + i)*4);
    }
    return length;
}

u32 XEuchw_Write_AB_6_Bytes(XEuchw *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XEUCHW_CONTROL_ADDR_AB_6_HIGH - XEUCHW_CONTROL_ADDR_AB_6_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_6_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XEuchw_Read_AB_6_Bytes(XEuchw *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XEUCHW_CONTROL_ADDR_AB_6_HIGH - XEUCHW_CONTROL_ADDR_AB_6_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_6_BASE + offset + i);
    }
    return length;
}

u32 XEuchw_Get_AB_7_BaseAddress(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_7_BASE);
}

u32 XEuchw_Get_AB_7_HighAddress(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_7_HIGH);
}

u32 XEuchw_Get_AB_7_TotalBytes(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XEUCHW_CONTROL_ADDR_AB_7_HIGH - XEUCHW_CONTROL_ADDR_AB_7_BASE + 1);
}

u32 XEuchw_Get_AB_7_BitWidth(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XEUCHW_CONTROL_WIDTH_AB_7;
}

u32 XEuchw_Get_AB_7_Depth(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XEUCHW_CONTROL_DEPTH_AB_7;
}

u32 XEuchw_Write_AB_7_Words(XEuchw *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XEUCHW_CONTROL_ADDR_AB_7_HIGH - XEUCHW_CONTROL_ADDR_AB_7_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_7_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XEuchw_Read_AB_7_Words(XEuchw *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XEUCHW_CONTROL_ADDR_AB_7_HIGH - XEUCHW_CONTROL_ADDR_AB_7_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_7_BASE + (offset + i)*4);
    }
    return length;
}

u32 XEuchw_Write_AB_7_Bytes(XEuchw *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XEUCHW_CONTROL_ADDR_AB_7_HIGH - XEUCHW_CONTROL_ADDR_AB_7_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_7_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XEuchw_Read_AB_7_Bytes(XEuchw *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XEUCHW_CONTROL_ADDR_AB_7_HIGH - XEUCHW_CONTROL_ADDR_AB_7_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XEUCHW_CONTROL_ADDR_AB_7_BASE + offset + i);
    }
    return length;
}

void XEuchw_InterruptGlobalEnable(XEuchw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEuchw_WriteReg(InstancePtr->Control_BaseAddress, XEUCHW_CONTROL_ADDR_GIE, 1);
}

void XEuchw_InterruptGlobalDisable(XEuchw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEuchw_WriteReg(InstancePtr->Control_BaseAddress, XEUCHW_CONTROL_ADDR_GIE, 0);
}

void XEuchw_InterruptEnable(XEuchw *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XEuchw_ReadReg(InstancePtr->Control_BaseAddress, XEUCHW_CONTROL_ADDR_IER);
    XEuchw_WriteReg(InstancePtr->Control_BaseAddress, XEUCHW_CONTROL_ADDR_IER, Register | Mask);
}

void XEuchw_InterruptDisable(XEuchw *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XEuchw_ReadReg(InstancePtr->Control_BaseAddress, XEUCHW_CONTROL_ADDR_IER);
    XEuchw_WriteReg(InstancePtr->Control_BaseAddress, XEUCHW_CONTROL_ADDR_IER, Register & (~Mask));
}

void XEuchw_InterruptClear(XEuchw *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEuchw_WriteReg(InstancePtr->Control_BaseAddress, XEUCHW_CONTROL_ADDR_ISR, Mask);
}

u32 XEuchw_InterruptGetEnabled(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XEuchw_ReadReg(InstancePtr->Control_BaseAddress, XEUCHW_CONTROL_ADDR_IER);
}

u32 XEuchw_InterruptGetStatus(XEuchw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XEuchw_ReadReg(InstancePtr->Control_BaseAddress, XEUCHW_CONTROL_ADDR_ISR);
}

