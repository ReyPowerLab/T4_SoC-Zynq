// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.1 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// control
// 0x0000 : Control signals
//          bit 0  - ap_start (Read/Write/COH)
//          bit 1  - ap_done (Read/COR)
//          bit 2  - ap_idle (Read)
//          bit 3  - ap_ready (Read/COR)
//          bit 7  - auto_restart (Read/Write)
//          others - reserved
// 0x0004 : Global Interrupt Enable Register
//          bit 0  - Global Interrupt Enable (Read/Write)
//          others - reserved
// 0x0008 : IP Interrupt Enable Register (Read/Write)
//          bit 0  - enable ap_done interrupt (Read/Write)
//          bit 1  - enable ap_ready interrupt (Read/Write)
//          others - reserved
// 0x000c : IP Interrupt Status Register (Read/TOW)
//          bit 0  - ap_done (COR/TOW)
//          bit 1  - ap_ready (COR/TOW)
//          others - reserved
// 0x0010 : Data signal of C
//          bit 31~0 - C[31:0] (Read)
// 0x0014 : Control signal of C
//          bit 0  - C_ap_vld (Read/COR)
//          others - reserved
// 0x0200 ~
// 0x03ff : Memory 'AB_0' (96 * 32b)
//          Word n : bit [31:0] - AB_0[n]
// 0x0400 ~
// 0x05ff : Memory 'AB_1' (96 * 32b)
//          Word n : bit [31:0] - AB_1[n]
// 0x0600 ~
// 0x07ff : Memory 'AB_2' (96 * 32b)
//          Word n : bit [31:0] - AB_2[n]
// 0x0800 ~
// 0x09ff : Memory 'AB_3' (96 * 32b)
//          Word n : bit [31:0] - AB_3[n]
// 0x0a00 ~
// 0x0bff : Memory 'AB_4' (96 * 32b)
//          Word n : bit [31:0] - AB_4[n]
// 0x0c00 ~
// 0x0dff : Memory 'AB_5' (96 * 32b)
//          Word n : bit [31:0] - AB_5[n]
// 0x0e00 ~
// 0x0fff : Memory 'AB_6' (96 * 32b)
//          Word n : bit [31:0] - AB_6[n]
// 0x1000 ~
// 0x11ff : Memory 'AB_7' (96 * 32b)
//          Word n : bit [31:0] - AB_7[n]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XEUCHW_CONTROL_ADDR_AP_CTRL   0x0000
#define XEUCHW_CONTROL_ADDR_GIE       0x0004
#define XEUCHW_CONTROL_ADDR_IER       0x0008
#define XEUCHW_CONTROL_ADDR_ISR       0x000c
#define XEUCHW_CONTROL_ADDR_C_DATA    0x0010
#define XEUCHW_CONTROL_BITS_C_DATA    32
#define XEUCHW_CONTROL_ADDR_C_CTRL    0x0014
#define XEUCHW_CONTROL_ADDR_AB_0_BASE 0x0200
#define XEUCHW_CONTROL_ADDR_AB_0_HIGH 0x03ff
#define XEUCHW_CONTROL_WIDTH_AB_0     32
#define XEUCHW_CONTROL_DEPTH_AB_0     96
#define XEUCHW_CONTROL_ADDR_AB_1_BASE 0x0400
#define XEUCHW_CONTROL_ADDR_AB_1_HIGH 0x05ff
#define XEUCHW_CONTROL_WIDTH_AB_1     32
#define XEUCHW_CONTROL_DEPTH_AB_1     96
#define XEUCHW_CONTROL_ADDR_AB_2_BASE 0x0600
#define XEUCHW_CONTROL_ADDR_AB_2_HIGH 0x07ff
#define XEUCHW_CONTROL_WIDTH_AB_2     32
#define XEUCHW_CONTROL_DEPTH_AB_2     96
#define XEUCHW_CONTROL_ADDR_AB_3_BASE 0x0800
#define XEUCHW_CONTROL_ADDR_AB_3_HIGH 0x09ff
#define XEUCHW_CONTROL_WIDTH_AB_3     32
#define XEUCHW_CONTROL_DEPTH_AB_3     96
#define XEUCHW_CONTROL_ADDR_AB_4_BASE 0x0a00
#define XEUCHW_CONTROL_ADDR_AB_4_HIGH 0x0bff
#define XEUCHW_CONTROL_WIDTH_AB_4     32
#define XEUCHW_CONTROL_DEPTH_AB_4     96
#define XEUCHW_CONTROL_ADDR_AB_5_BASE 0x0c00
#define XEUCHW_CONTROL_ADDR_AB_5_HIGH 0x0dff
#define XEUCHW_CONTROL_WIDTH_AB_5     32
#define XEUCHW_CONTROL_DEPTH_AB_5     96
#define XEUCHW_CONTROL_ADDR_AB_6_BASE 0x0e00
#define XEUCHW_CONTROL_ADDR_AB_6_HIGH 0x0fff
#define XEUCHW_CONTROL_WIDTH_AB_6     32
#define XEUCHW_CONTROL_DEPTH_AB_6     96
#define XEUCHW_CONTROL_ADDR_AB_7_BASE 0x1000
#define XEUCHW_CONTROL_ADDR_AB_7_HIGH 0x11ff
#define XEUCHW_CONTROL_WIDTH_AB_7     32
#define XEUCHW_CONTROL_DEPTH_AB_7     96

